package com.ssafy.fit.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.fit.model.dao.VideoDao;
import com.ssafy.fit.model.dto.Video;
@Service
public class VideoServiceImpl implements VideoService{
	
	@Autowired
	private VideoDao dao;
	
	@Override
	public List<Video> getList() {
		return dao.selectAll();
	}

	@Override
	public List<Video> getPart(String part) {
		return dao.selectPart(part);
	}

	@Override
	public Video selectOne(String youtubeId) {
		return dao.selectOne(youtubeId);
	}

}
