package com.ssafy.fit.model.service;

import java.util.List;

import com.ssafy.fit.model.dto.Video;

public interface VideoService {
	
	List<Video> getList();
	
	List<Video> getPart(String part);
	
	Video selectOne(String youtubeId);

}
