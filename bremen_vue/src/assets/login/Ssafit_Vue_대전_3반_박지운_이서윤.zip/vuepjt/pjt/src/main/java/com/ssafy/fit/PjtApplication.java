package com.ssafy.fit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PjtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PjtApplication.class, args);
	}

}
