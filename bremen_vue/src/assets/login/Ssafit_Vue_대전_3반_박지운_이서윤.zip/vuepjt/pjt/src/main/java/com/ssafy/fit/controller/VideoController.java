package com.ssafy.fit.controller;

import java.util.List;

import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.fit.model.dto.Video;
import com.ssafy.fit.model.service.VideoService;

@RestController
@RequestMapping("/videoapi")
@CrossOrigin("*")
public class VideoController extends HttpServlet {
	@Autowired
	private VideoService service;

	@GetMapping("/videos")
	protected ResponseEntity<?> selectVideoList() {
		List<Video> video = service.getList();
		return new ResponseEntity<List<Video>>(video, HttpStatus.CREATED);
	}
	@GetMapping("/videos/{part}")
	public ResponseEntity<?> list(@PathVariable String part) {
		List<Video> video = service.getPart(part);
		if(video == null || video.size() == 0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Video>>(video, HttpStatus.OK);
	}
	
	@GetMapping("/videos/search/{youtubeId}")
	public ResponseEntity<?> selectOne(@PathVariable String youtubeId) {
		Video video = service.selectOne(youtubeId);
		if(video == null)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<>(video, HttpStatus.OK);
	}

}
