package com.ssafy.fit.model.dao;

import java.util.List;

import com.ssafy.fit.model.dto.Video;

public interface VideoDao {
	List<Video> selectAll();
	

	List<Video> selectPart(String part);
	
	
	Video selectOne(String id);
	
	
	
}
