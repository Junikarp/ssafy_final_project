CREATE TABLE IF NOT EXISTS `video` (
	`title` varchar(100) CHARACTER SET utf8mb4 NOT NULL ,
    `fitPartName` varchar(100) CHARACTER SET utf8mb4 NOT NULL ,
    `youtubeId` varchar(100) CHARACTER SET utf8mb4 NOT NULL ,
    `channelName` varchar(100) CHARACTER SET utf8mb4 NOT NULL ,
    `viewCnt` int(40) NOT NULL ,
    `URL` varchar(100) CHARACTER SET utf8mb4 NOT NULL PRIMARY KEY
 
)ENGINE=InnoDB;
INSERT INTO `video` (title, fitPartName, youtubeId, channelName, viewCnt,URL)
VALUES 
("전신 다이어트 최고의 운동", "전신", "gMaB-fG4u4g", "ThankyouBUBU", 0, "https://www.youtube.com/embed/gMaB-fG4u4g"),
("하루 15분! 전신 칼로리 불태우는 다이어트 운동", "전신", "swRNeYw1JkY", "ThankyouBUBU", 0, "https://www.youtube.com/embed/swRNeYw1JkY"),
("상체 다이어트 최고의 운동 BEST [팔뚝살/겨드랑이살/등살/가슴어깨라인]", "상체", "54tTYO-vU2E", "ThankyouBUBU", 0, "https://www.youtube.com/embed/54tTYO-vU2E");


CREATE TABLE IF NOT EXISTS `board` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(45) NOT NULL,
  `writer` VARCHAR(45) NOT NULL,
  `content` VARCHAR(200) NOT NULL,
  `reg_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `view_cnt` INT NULL DEFAULT NULL,
  `videoId` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
	CONSTRAINT `videoID` FOREIGN KEY (`videoId`) REFERENCES `video` (`youtubeId`)
  );

INSERT INTO `review` (name, title, content,viewcount,regDate,url) 
VALUES
('심규리', '정말재미있네여','굳굳궁',0,20231013,"https://www.youtube.com/embed/gMaB-fG4u4g"),
('배규리', '정말정말재미있네여','굳굳정말',0,20231014,"https://www.youtube.com/embed/swRNeYw1JkY"),
('최규리', '정말정말정말재미있네여','굳정말굳정말',0,20231015,"https://www.youtube.com/embed/54tTYO-vU2E");

select * from video;






commit;


