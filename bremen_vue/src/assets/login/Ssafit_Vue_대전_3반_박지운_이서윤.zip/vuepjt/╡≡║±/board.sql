USE ssafy_board;

DROP table board;

CREATE TABLE board (
    id INT AUTO_INCREMENT,
    writer VARCHAR(20) NOT NULL,
    title VARCHAR(50) NOT NULL,
    content TEXT,
    viewcnt INT DEFAULT 0,
    regdate TIMESTAMP DEFAULT now(),
    videoid VARCHAR(100),
    PRIMARY KEY(id)
);

INSERT INTO board(title, writer, content) 
VALUES ("이게맞나....","양씨","너도 할 수 있어"),
       ("뷰이게맞ㄴㅏ....", "따봉맨", "ㅎㅏ....."),
       ("나는멍청이", "조용환", "ㅜㅜ"),
       ("선장님...가지마세요", "ㅇㅇ", "우리팀이 더 급해요......"),
       ("저희같은배를탓어요", "조용환", "흑....");
       
SELECT * FROM board; 