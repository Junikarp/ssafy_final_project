<template>
    <div>
      <VideoList class="test1"></VideoList>
      <VideoPart class="test1"></VideoPart>
    </div>
</template>

<script setup>

import VideoPart from '@/components/video/VideoPart.vue';
import VideoList from '@/components/video/VideoList.vue';
</script>

<style scoped>

</style>