<template>
    <div class="container">
         <div v-for="video in videoList" :key="video.id" class="videocard">
             <div>
                 <iframe width="310" height="178" :src="video.url" title="YouTube video player" frameborder="0"
                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                     allowfullscreen></iframe>
             </div>
             <div>
                 <div>
                     {{ video.title }}</div>
                 <p class="card-text"></p>
             </div>
             <div>
                 <span>{{ video.part }}</span>
                 <p class="card-text">{{ video.channelName }}</p>
 
             </div>
         </div>
     </div>
 </template>
 
 <script setup>
 
 const videoList = 
 [ {id: 5, title: "하체운동이 중요한 이유? 이것만 보고 따라하자 ! [하체운동 교과서]", part: "하체", channelName: "김강민", url: "https://www.youtube.com/embed/tzN6ypk6Sps" },
 {id: 6, title:"저는 하체 식주의자 입니다", part:"하체", channelName:"GYM종국",url: "https://www.youtube.com/embed/u5OgcZdNbMo"}]
 
 </script>
 
 <style scoped>
 .container {
     margin-top: 20px;
     display: flex;
     justify-content: center;
 }
 
 .videocard{
     align-items: center;
     width: 310px;
     height: 100%s;
     margin: 20px;
 }
 </style>