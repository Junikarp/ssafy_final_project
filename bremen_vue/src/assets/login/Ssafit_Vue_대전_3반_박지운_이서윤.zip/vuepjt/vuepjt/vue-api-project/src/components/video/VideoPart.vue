<template>
    <div class="whole-container">
        <div class="part-container">
            <div>
                <h2>운동 부위 선택</h2>
            </div>
            <div class="linklist">
                <router-link :to="{name: 'videoAll'} " type="button" >전신</router-link>
                <router-link :to="{name: 'videoUp'} " type="button">상체</router-link>
                <router-link :to="{name: 'videoDown'} " type="button">하체</router-link>
                <router-link :to="{name: 'videoBelly'} " type="button">복부</router-link>
            </div>
        </div>
            <div class="router">
                <router-view></router-view>
            </div>
    </div>
</template>

<script setup>

</script>

<style scoped>

h2{
    margin: 20px;
}
.part-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}
.linklist{
    display: flex;
    justify-content: space-around;
    gap: 10px;;
}

.router{
    display: flex;
    justify-content: center;
}

a{
    padding: 5px;
    border: 1px solid gray;
    text-decoration: none;
}


</style>