<template>
    <div>
        <div>로그아웃 하시겠습니까?</div>
        <button @click="logoutUser">로그아웃</button>
    </div>
</template>

<script setup>
import { ref } from "vue";
import { useUserStore } from "@/stores/user";

const store = useUserStore()

const logoutUser =  ()=> {
    store.logoutUser()
}
</script>

<style scoped>

</style>