import { createRouter, createWebHistory } from 'vue-router'

import HomeView from '@/views/HomeView.vue'
import LoginView from '@/views/LoginView.vue'
import SignView from '@/views/SignView.vue'
import VideoPart from '@/components/video/VideoPart.vue'
import VideoList from '@/components/video/VideoList.vue'
import VideoAll from '@/components/video/VideoAll.vue'
import VideoUp from '@/components/video/VideoUp.vue'
import VideoDown from '@/components/video/VideoDown.vue'
import VideoBelly from '@/components/video/VideoBelly.vue'

import BoardView from '@/views/BoardView.vue'
import BoardList from '@/components/board/BoardList.vue'
import BoardCreate from '@/components/board/BoardCreate.vue'
import BoardDetail from '@/components/board/BoardDetail.vue'
import BoardUpdate from '@/components/board/BoardUpdate.vue'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {path: "/part",
    name: "videoPart",
    component: VideoPart,
    children: [
      {
        path: 'all',
        name: "videoAll",
        component: VideoAll
      },
      {
        path: 'up',
        name: "videoUp",
        component: VideoUp
      },
      {
        path: 'down',
        name: "videoDown",
        component: VideoDown
      },
      {
        path: 'belly',
        name: "videoBelly",
        component: VideoBelly
      },


    ]
  
  },
    {
      path: "/list",
      name: "videoList",
      component: VideoList
    },
    {
      path: '/login',
      name: 'login',
      component: LoginView,
    },
    {
      path: '/sign',
      name: 'sign',
      component: SignView,
    },
    {
      path: '/board',
      name: 'board',
      component: BoardView,
      children: [
        {
          path: "",
          name: "boardList",
          component: BoardList},
          
            {
              path: ":youtubeId",
              name: "BoardList",
              component: BoardList
            },
        
        {
          path: "/:youtubeId/create",
          name: "boardCreate",
          component: BoardCreate
        },
        {
          path: ":youtubeId/:id",
          name: "boardDetail",
          component: BoardDetail
        },
        {
          path: ":youtubeId/:id/update",
          name: "boardUpdate",
          component: BoardUpdate
        },
      ]
    },
  ]
})

export default router
