<template>
    <div class="container">
         <div v-for="video in videoList" :key="video.id" class="videocard">
             <div>
                 <iframe width="310" height="178" :src="video.url" title="YouTube video player" frameborder="0"
                     allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                     allowfullscreen></iframe>
             </div>
             <div>
                 <div>
                     {{ video.title }}</div>
                 <p class="card-text"></p>
             </div>
             <div>
                 <span>{{ video.part }}</span>
                 <p class="card-text">{{ video.channelName }}</p>
 
             </div>
         </div>
     </div>
 </template>
 
 <script setup>
 
 const videoList = 
 [ {id: 3, title: "상체 다이어트 최고의 운동 BEST [팔뚝살/겨드랑이살/등살/가슴어깨라인]", part: "상체", channelName: "ThankyouBUBU", url: "https://www.youtube.com/embed/54tTYO-vU2E" },
 {id: 4, title:"상체비만 다이어트 최고의 운동 [상체 핵매운맛]", part:"전신", channelName:"ThankyouBUBU",url: "https://www.youtube.com/embed/QqqZH3j_vH0"}]
 
 </script>
 
 <style scoped>
 
 .container {
     margin-top: 20px;
     display: flex;
     justify-content: center;
 }
 
 .videocard{
     align-items: center;
     width: 310px;
     height: 100%s;
     margin: 20px;
 }
 
 </style>