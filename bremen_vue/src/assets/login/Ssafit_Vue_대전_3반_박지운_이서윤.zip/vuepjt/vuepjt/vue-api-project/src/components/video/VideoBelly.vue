<template>
    <div class="container">
        <div v-for="video in videoList" :key="video.id" class="videocard">
            <div>
                <iframe width="310" height="178" :src="video.url" title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            </div>
            <div>
                <div>
                    {{ video.title }}</div>
                <p class="card-text"></p>
            </div>
            <div>
                <span>{{ video.part }}</span>
                <p class="card-text">{{ video.channelName }}</p>

            </div>
        </div>
    </div>

</template>

<script setup>

const videoList = 
[ {id: 7, title: "11자복근 복부 최고의 운동 [복근 핵매운맛]", part: "복부", channelName: "ThankyouBUBU", url: "https://www.youtube.com/embed/PjGcOP-TQPE" },
{id: 8, title:"(Sub)누워서하는 5분 복부운동!! 효과보장! (매일 2주만 해보세요!)", part:"복부", channelName:"SomiFit",url: "https://www.youtube.com/embed/7TLk7pscICk"}]

</script>

<style scoped>
.container {
    margin-top: 20px;
    display: flex;
    justify-content: center;
}

.videocard{
    align-items: center;
    width: 310px;
    height: 100%s;
    margin: 20px;
}
</style>