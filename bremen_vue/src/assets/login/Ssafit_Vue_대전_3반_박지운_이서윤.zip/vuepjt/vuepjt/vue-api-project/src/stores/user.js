import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import axios from 'axios'
import { useRoute, useRouter } from 'vue-router'
const REST_USER_API = `http://localhost:8080/userapi`


export const useUserStore = defineStore('user', () => {

    const LoginUser = ref({name:''})

    const router = useRouter();    // 사용자 회원가입
    const signupUser = function (user) {
        console.log(user)
        axios({
            url: REST_USER_API+"/signup",
            method: 'POST',
            data: user
        })
            .then(() => {
                router.push({ name: 'home' })
            })


    }
    const userlist = ref(false)
    // 사용자 로그인
    const loginUser = function (user) {
        axios({
            url: REST_USER_API + "/login",
            method: 'POST',
            params: user
        }).then ((user) => {
            router.push({ name: 'home' })
            LoginUser.value = user.data
        })
    }

    // 사용자 로그아웃
    const logoutUser = function () {
        LoginUser.value = {name:''};
    }


    return { signupUser, loginUser, logoutUser, LoginUser }
})