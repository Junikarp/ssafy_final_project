import { ref, computed } from 'vue'
import { defineStore } from 'pinia'
import router from '@/router'
import axios from 'axios'

const VIDEO_API = `http://localhost:8080/videoapi/videos`


export const useVideoStore = defineStore('video', () => {
  const videoList = ref([])
  const video = ref()
  const getVideoList = function () {
    axios.get(`${VIDEO_API}`)
      .then((response) => {
      videoList.value = response.data
      console.log(videoList.value)
      })

  }

  const getVideo = function (part) {
    axios.get(`${VIDEO_API}/${part}`)
      .then((response) => {
      videoList.value = response.data
      console.log(videoList.value)
      })
  }

  const getVideoOne = function (youtubeId) {
    axios.get(`${VIDEO_API}/${youtubeId}`)
      .then((response) => {
      videoList.value = response.data
      console.log(videoList.value)
      })
  }

  return {video, videoList, getVideoList, getVideo, getVideoOne}

})

