<template>
        <div>
        <header>
            <div class="logo">
                <router-link to="/">홈</router-link>
            </div>
            <div class="ls" v-if="userStore.LoginUser.name == ''">
                <RouterLink to="/login" class="lss">로그인</RouterLink>
                <router-link to="/sign" class="lss">회원가입</router-link>
            </div>
            <div class="ls" v-else>
                <div class="lss">
                {{userStore.LoginUser.name}}님 hi
                <button @click="logoutUser">로그아웃</button>
                <router-link to="/sign" class="lss">회원가입</router-link >
            </div>
            </div>
        </header>
    </div>
</template>

<script setup>
import { useUserStore } from '@/stores/user';

const userStore = useUserStore();

const logoutUser =  ()=> {
    userStore.logoutUser()
}



</script>

<style  scoped>
div {
    font-family: Poppins, 'Noto Sans KR', sans-serif;
}

header{
    display: flex;
    justify-content: space-around;
    align-items: center;
    text-align: center;
    transition: 0.2s;
    padding-top: 10px;
    padding-bottom: 10px;
}

.ls{
    display: flex;
    align-items: center;
    justify-content: space-around;
    gap: 15px;
}

a{
    text-decoration: none;
    font-weight: bold;
    color: rgb(0, 110, 255);
}

.logo:hover{
    color: rgb(0, 110, 220);
    text-decoration: none;
    background-color: beige;
    transform: scale(1.2);
}

.lss:hover{
    color: white;
    text-decoration: none;
    background-color: rgb(0, 110, 255);
    transform: scale(1.2);
}
</style>