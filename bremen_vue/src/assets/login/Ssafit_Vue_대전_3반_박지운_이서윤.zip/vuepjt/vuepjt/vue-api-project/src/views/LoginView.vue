<template>
    <div>
        <div class="inpt">
            <form>
                <input v-model="user.id" type="text" >
                <input v-model="user.password" type="password" placeholder="password">
            </form>
            <button @click="loginUser">Login</button>
        </div>
    </div>
</template>

<script setup>
import { ref } from "vue";
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from "@/stores/user";


const router = useRouter();
const store = useUserStore()
const user = ref({
    id: '',
    password: ''
})

const loginUser =  ()=> {
    store.loginUser(user.value)
}
</script>

<style scoped>
.inpt {
    display: flex;
    flex-direction: column;
    margin-top: 50px;
    padding: 10px;
    justify-content: center;
    align-items: center;
}

form {
    background-color: #FFFFFF;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 100%;
    height: 100%;
    text-align: center;
}

input {
    background-color: #eee;
    width: 30%;
    border: none;
    padding: 12px 15px;
    margin: 8px 0;
}

input::placeholder{
    text-align: center;
    font-weight: lighter;
    font-family: Poppins, 'Noto Sans KR', sans-serif;
}

button{
    width: 30%;
}

</style>