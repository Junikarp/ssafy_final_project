<template>
    <div class="container">
        <div v-for="video in videoStore.videoList" :key="video.id" class="videocard">
            <div class="watching">
                <iframe width="310" height="178" :src="video.url" title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe>
            </div>
            <div>
                <router-link :to="`/board/${video.id}`">{{ video.title }}</router-link>                 
                <p class="card-text"></p>
            </div>
            <div>
                <span>{{ video.part }}</span>
                <p class="card-text">{{ video.channelName }}</p>

            </div>
        </div>
    </div>
</template>

<script setup>
import { useVideoStore } from '@/stores/video';
import { computed, onMounted } from 'vue';

const videoStore = useVideoStore()

onMounted(() => {
    videoStore.getVideoList()
    console.log(videoStore.videoList)
})
</script>

<style scoped>
.container {
    margin-top: 20px;
    display: flex;
    justify-content: center;
}

.videocard{
    align-items: center;
    width: 310px;
    height: 100%;
    margin: 10px;
}
</style>