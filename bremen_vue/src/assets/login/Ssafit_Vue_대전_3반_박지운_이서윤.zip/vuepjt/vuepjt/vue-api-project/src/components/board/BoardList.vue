<template>
    <div>
        <h4>게시글 목록</h4>
        <hr>
        <table>
            <tr>
                <th>번호</th>
                <th>제목</th>
                <th>쓰니</th>
                <th>조회수</th>
                <th>등록</th>
            </tr>
            <template v-for="board in store.boardList" :key="board.id">
            <tr v-if="board.youtubeId == vurl">
                <td>{{ board.id }}</td>
                <td>
                    <RouterLink :to="`/board/${vurl}/${board.id}`">{{ board.title }}</RouterLink>
                </td>
                <td>{{ board.writer }}</td>
                <td>{{ board.viewCnt }}</td>
                <td>{{ board.regDate }}</td>
            </tr>
        </template>
        </table>
        <RouterLink :to="{ name: 'boardCreate' }">글 작성</RouterLink>
        <BoardSearchInput />
    </div>
</template>

<script setup>
import { useBoardStore } from "@/stores/board";
import { useRoute, useRouter } from 'vue-router'
import { onMounted } from "vue";
import BoardSearchInput from "./BoardSearchInput.vue";

const store = useBoardStore()

const route = useRoute();
const router = useRouter();

const vurl = route.params.youtubeId;
 
onMounted(() => {
    store.getBoardList()
    console.log(route.params.youtubeId)
})

</script>

<style scoped></style>