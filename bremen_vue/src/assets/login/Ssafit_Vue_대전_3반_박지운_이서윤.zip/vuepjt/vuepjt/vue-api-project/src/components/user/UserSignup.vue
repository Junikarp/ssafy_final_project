<template>
    <div>
        <h2>Sign-Up</h2>
        <fieldset>
            <legend>SIGN-UP</legend>
            <div>
                <label for="name">이름 : </label>
                <input type="text" id="name" v-model="user.name">
            </div>
            <div>
                <label for="id">ID : </label>
                <input type="text" id="id" v-model="user.id">
            </div>
            <div>
                <label for="password">PASSWORD : </label>
                <input type="text" id="password" v-model="user.password">
            </div>
            <div>
                <label for="passwordSecond">PASSWORD 재확인 : </label>
                <input type="text" id="passwordSecond">
            </div>
            <div>
                <button @click="signupUser">회원가입</button>
            </div>
        </fieldset>
    </div>
</template>

<script setup>
import { ref } from "vue";
import { useUserStore } from "@/stores/user";

const store = useUserStore()
const user = ref({
    name: '',
    id: '',
    password: '',
    
})

const passwordSecond = ref('')

const signupUser = function() {
    store.signupUser(user.value)
}


</script>

<style scoped>

</style>