package com.bremen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BremenApplication {

	public static void main(String[] args) {
		SpringApplication.run(BremenApplication.class, args);
	}

}
